97.1 The Fan Addon for Kodi
-------------------------------------------

97.1 The Fan - Your Source for The Buckeyes

INSTALL:

To install Kodi addons follow the directions found here: http://kodi.wiki/view/HOW-TO:Install_add-ons_from_zip_files
